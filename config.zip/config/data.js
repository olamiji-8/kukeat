const data = [
  {
    id: 1,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Pasta",
  },

  {
    id: 2,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Pasta",
  },

  {
    id: 3,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Pasta",
  },

  {
    id: 4,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Pasta",
  },

  {
    id: 5,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Pasta",
  },

  {
    id: 6,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Pasta",
  },

  {
    id: 7,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Pasta",
  },

  {
    id: 8,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",

    category: "Pasta",
  },

  {
    id: 9,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Groceries",
  },

  {
    id: 10,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Groceries",
  },

  {
    id: 11,
    title: "Golden Penny Noodles",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Groceries",
  },

  {
    id: 12,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Groceries",
  },

  {
    id: 13,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Groceries",
  },

  {
    id: 14,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Groceries",
  },

  {
    id: 15,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Groceries",
  },

  {
    id: 16,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Groceries",
  },

  {
    id: 17,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Beverages",
  },

  {
    id: 18,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Beverages",
  },

  {
    id: 19,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Beverages",
  },

  {
    id: 20,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Beverages",
  },

  {
    id: 21,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Beverages",
  },

  {
    id: 22,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Beverages",
  },

  {
    id: 23,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Beverages",
  },

  {
    id: 24,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Beverages",
  },

  {
    id: 25,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Swallow",
  },

  {
    id: 26,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Swallow",
  },

  {
    id: 27,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Swallow",
  },

  {
    id: 28,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Swallow",
  },

  {
    id: 29,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Swallow",
  },

  {
    id: 30,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Swallow",
  },

  {
    id: 31,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Swallow",
  },

  {
    id: 32,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Swallow",
  },

  {
    id: 33,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Oil",
  },

  {
    id: 34,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Oil",
  },

  {
    id: 35,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Oil",
  },

  {
    id: 36,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Oil",
  },

  {
    id: 37,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#600",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055137/dyayctijvjplnsoz1v77.png",
    category: "Oil",
  },

  {
    id: 38,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/y3hswtjim8ucs1sktert.png",
    category: "Oil",
  },

  {
    id: 39,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#900",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/uemknao2yx2yiipqr5it.png",
    category: "Oil",
  },

  {
    id: 40,
    title: "Golden Penny Twist",
    description: "Lorem ipsum dolor sit amet tetur mattis vel dhc kd.",
    price: "#800",
    image:"https://res.cloudinary.com/dxd1j0yzt/image/upload/v1700055138/m89yr73ost6kb6blvou4.png",
    category: "Oil",
  },
];

module.exports = data;